package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.utility.ExcelFunctionsUtility;

public class Login {
	WebDriver driver;
	@FindBy(how = How.ID,using = "Email")
	WebElement email;
	@FindBy(how = How.ID,using = "Password")
	WebElement password;
	@FindBy(how = How.CSS,using = "input[value='Log in']")
	WebElement loginButton;
	@FindBy(how=How.LINK_TEXT,using = "Log out")
	WebElement logout;
	
	
	@Test(dataProvider="dp2")
	public boolean loginButtonClick(String excelemail, String excelPassword)
	{
	email.sendKeys(excelemail);
	password.sendKeys(excelPassword);
	loginButton.click();
	return logout.isDisplayed();
	}
	

	public void logout()
	{
	logout.click();
	}

	

}
